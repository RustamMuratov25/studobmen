<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина</title>

    {{-- Подключаем CSS через Vite --}}
    @vite(['resources/css/1.css'])
</head>
<body>
    <div class="main-wrapper">
    <header>
        <div>
            <a href="{{ route('home') }}">
                <img src="{{ asset('images/лого_с_надписью.svg') }}" id="tpu_logo" alt="Лого ТПУ" >
            </a>
        </div>

        <div class="right">
            <div>
                <a href="{{ route('selected') }}">
                    <img src="{{ asset('images/selected.svg') }}" alt="избранное" >
                </a>
            </div>

            <div>
                <a href="{{ route('basket') }}">
                    {{-- Обновлено имя файла иконки корзины из вашего кода --}}
                    <img src="{{ asset('images/fluent_cart-24-filled.svg') }}" alt="корзина" >
                </a>
            </div>

            <div>
                <img src="{{ asset('images/account.svg') }}">
            </div>
        </div>
    </header>

    <div class="underhead">
        <a href="{{ route('create') }}">
            <button>Разместить объявление</button>
        </a>

        <a href="{{ route('my_notices') }}">
            <button>Мои объявления</button>
        </a>

        <div class="search">
            <img id="magni" src="{{ asset('images/magnifier.svg') }}">
            <form>
                <input type="text" placeholder="Поиск объявлений">
                <input type="submit" value="Найти">
            </form>
        </div>

        <div id="moon">
            <a href="{{ asset('html_dark_theme/basket.html') }}">
                <img src="{{ asset('images/moon.svg') }}">
            </a>
        </div>
    </div>

    <main>
        <div class="headline">Корзина</div>
        <div class="list of notices">
            <div class="card">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBXeX1ZkrPbHF9oueV_j_k1ll1YDT32oIx7A&s" class="product_image" alt="Фото товара">

                <img id="heart" src="{{ asset('images/heart_void.svg') }}">

                <p id="name">SuperMegaUltraDooperClass</p>
                <p id="price">Вагон говяжей тушенки</p>
                <p id="adress">Адрес: город Москва, 3 улица Строителей, дом 1, кв 12</p>
            </div>
        </div>
    </main>

    <footer>
        <p>Томский политехнический университет 2026<br>Студобмен</p>
        <div class="connection">
            <a href="https://vk.me/join/AGcUKMcOAg6Lru/28YKDQQNoup9gEvd0IiM=" target="_blank" class="social_networks">
                {{-- Если вы скачали эти иконки в public/images, замените URL на asset() --}}
                <img width="40" src="https://images.icon-icons.com/3781/PNG/512/vk_icon_231956.png" alt="VK">
            </a>

            <a href="https://t.me/@Komolaich" class="social_networks" target="_blank">
                <img width="40" src="https://freesvg.org/img/new-instagram-logo-glyph.png" alt="Instagram">
            </a>

            <a href="" target="_blank" class="social_networks">
                <img width="70" src="https://svgsilh.com/png-512/2071331.png" alt="">
            </a>

            <a href="" target="_blank" class="social_networks">
                <img width="40" src="https://www.svgrepo.com/show/342286/telegram.svg" alt="Telegram">
            </a>
        </div>
    </footer>
    </div>
</body>
</html>
