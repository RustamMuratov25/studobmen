<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <script src="{{ asset('javascript/code.js') }}"></script>
    @vite(['resources/css/2.css'])
</head>
<body>
    <div class="main-wrapper">
    <header>
        <div>
            <a href="{{ route('home.v2') }}">
                <img src="{{ asset('images/лого_белое.svg') }}" id="tpu_logo" alt="Лого ТПУ" >
            </a>
        </div>

        <div class="right">
            <div>
                <a href="{{ route('selected.v2') }}">
                    <img src="{{ asset('images/white_full_heart.svg') }}" alt="избранное" >
                </a>
            </div>

            <div>
                <a href="{{ route('basket.v2') }}">
                    <img src="{{ asset('images/white_cart.svg') }}" alt="корзина" >
                </a>
            </div>

            <div id="acc">
                <img src="{{ asset('images/white_account.svg') }}">
            </div>
        </div>
</header>

<div class="underhead">
    <a href="{{ route('create.v2') }}">
        <button >Разместить объявление</button>
    </a>

    <a href="{{ route('my_notices.v2') }}">
        <button>Мои объявления</button>
    </a>

    <div class="search">
        <img id="magni" src="{{ asset('images/magnifier.svg') }}">
        {{-- Добавили action и метод для работы поиска на темной теме --}}
        <form action="{{ route('ads.search') }}" method="GET">
            <input type="text" name="search" value="{{ $query ?? request('search') }}" placeholder="Поиск объявлений">
            <input type="submit" value="Найти">
        </form>
    </div>

    <div id="moon">
        <a href="{{ route('home') }}">
            <img src="{{ asset('images/white_moon.svg') }}">
        </a>
    </div>
</div>

    <main>
        <div class="categories">
            <div class="row">
                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/dishes.svg') }}">
                        <span class="name">Посуда</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/chancery.svg') }}">
                        <span class="name">Канцелярия</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/textile.svg') }}">
                        <span class="name">Текстиль</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/periphery.svg') }}">
                        <span class="name">Периферия</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/gadgets.svg') }}">
                        <span class="name">Гаджеты</span>
                    </div>
                </div>

                <div class="icon" id="merch">
                    <div class="content" >
                        <img src="{{ asset('images/ТПУ лого белый13 1.svg') }}">
                        <span class="name">Мерч</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/sport.svg') }}">
                        <span class="name">Спорт</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/boardgames.svg') }}">
                        <span class="name">Настолки</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/gaming.svg') }}">
                        <span class="name">Гейминг</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/creation.svg') }}">
                        <span class="name">Творчество</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/outerwear.svg') }}">
                        <span class="name">Верхняя одежда</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/books.svg') }}">
                        <span class="name">Учебники и пособия</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/components.svg') }}">
                        <span class="name">Комплектующие</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/coursework.svg') }}">
                        <span class="name">Курсовые и проекты</span>
                    </div>
                </div>

                <div class="icon">
                    <div class="content">
                        <img src="{{ asset('images/household.svg') }}">
                        <span class="name">Бытовая техника</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="headline">
            @if(isset($query) && $query !== '')
                Результаты поиска по запросу: "{{ $query }}"
            @else
                Последние объявления
            @endif
        </div>

        <div class="list of notices">
            {{-- Заменили статичную верстку на динамический вывод из БД --}}
            @forelse($ads as $ad)
                <a href="{{ route('item.v2', $ad->advertisements_id ?? '') }}">
                    <div class="card">
                        @php
                            $mainImage = $ad->images->firstWhere('is_main', true) ?? $ad->images->first();
                        @endphp

                        @if($mainImage)
                            <img src="{{ asset($mainImage->image_url) }}" class="product_image" alt="{{ $ad->title }}">
                        @else
                            {{-- Заглушка, если картинок у объявления нет вообще --}}
                            <img src="{{ asset('images/white_account.svg') }}" class="product_image" alt="Нет фото">
                        @endif

                        <a><img id="heart" src="{{ asset('images/white_heart.svg') }}"></a>

                        <p id="name">{{ $ad->title }}</p>
                        <p id="price">{{ number_format($ad->price, 0, '.', ' ') }} ₽</p>
                        <p id="adress">Адрес: {{ $ad->address }}</p>
                    </div>
                </a>
            @empty
                <div style="text-align: center; color: #aaa; width: 100%; padding: 20px; grid-column: span 4;">
                    По вашему запросу ничего не найдено.
                </div>
            @endforelse
        </div>
    </main>

    <footer>
        <p>Томский политехнический университет 2026<br>Студобмен</p>
        <div class="connection">
            <a href="https://vk.me/join/AGcUKMcOAg6Lru/28YKDQQNoup9gEvd0IiM=" target="_blank" class="social_networks" alt="Связаться с нами в вк" >
                <img width="40px" src="https://icon-icons.com/3781/PNG/512/vk_icon_231956.png" alt="">
            </a>

            <a href="https://t.me/@Komolaich" class="social_networks" target="_blank" alt="Связаться с нами в тг" >
                <img width="40px" src="https://www.svgrepo.com/show/342286/telegram.svg" alt="">
            </a>

            <a href="" target="_blank" class="social_networks">
                <img width="70px" src="https://svgsilh.com/png-512/2071331.png" alt="">
            </a>
        </div>
    </footer>
    </div>
</body>
</html>
